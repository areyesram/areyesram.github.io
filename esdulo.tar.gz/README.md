# Es Du/Lo

<small>(Elasticsearch Dump / Load)</small>

Substituto del mecanismo estándar de Snapshot/Restore de Elasticsearch.
Pretende ser lo más simple posible siendo aun así utilizable.

## Escenario

Se desea realizar una réplica de producción en un ambiente de desarrollo o pruebas.
En este caso, se pueden usar diferentes alternativas:

## Alternativas

### Realizar un snapshot

- Pros:
  - Es un mecanismo estándar.
- Cons:
  - Depende de tener un bucket en la nube o un share disponible desde ambos ambientes.

### Copiar el directorio data

- Pros:
  - Simple.
- Cons:
  - Hay que copiar todos los datos aunque no se requieran.
  - Se necesita una instancia nueva de Elasticsearch.

### Usar esdulo

- Pros:
  - Simple.
- Cons:
  - Solo se puede procesar un índice a la vez.
  - No tiene capacidades de filtrado.

## Uso

    node esdulo.js [ -h es_host ] { -i index | -d directory }

- es_host = Nodo de Elasticsearch de origen o destino
- index = Nombre del índice de origen.
- directory = Ruta absoluta o relativa del directorio de origen.

### Observaciones

- La acción a realizar se determina por los parámetros. Si se usa `-i`, se asume que la acción es descargar los datos del índice dado (_dump_). Si se usa `-d`, se asume que se cargarán los datos del directorio dado en un índice (_load_).
- Ya sea `-i` o `-d` es requerido. El parámetro `-h` es opcional y vale `http://localhost:9200` por default.
- Al usar la opción `-i`, se crea un directorio con el nombre del índice unido a un timestamp con el caracter `#`. Ejemplo: `metrics-20210701#1625159175815`. Dentro de este se crean archivos JSON con la estructura y los datos del índice dado.
- Al usar la opción `-d`, el nombre del índice se determina con el prefijo del nombre del directorio (parte a la izquierda del `#`)

## Problemas conocidos

Si se respalda un índice de un cluster de la versión 6.8 o anterior, el archivo mappings.json generado puede contener un "type name" (por ejemplo **doc** o **_doc**) que a partir de la versión 7.0 se volvió obsoleto.

Para resolver esto, es necesario editar el archivo mappings.json para eliminar el _type name_ y elevar el contenido un nivel.

Ejemplo:

    {
        "mappings": {
            "doc": {
                "properties": {
                    ...
                }
            }
        }
    }

⮕

    {
        "mappings": {
            "properties": {
                ...
            }
        }
    }

Nota: Puede ocurrir una situación similar en el caso contrario.
