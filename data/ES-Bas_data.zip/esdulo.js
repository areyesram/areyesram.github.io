const fs = require("fs");
const path = require("path");
const { Client } = require("@elastic/elasticsearch");

(async () => {
    const p = parseArgs();
    if (!p.action) return;
    const es = new Client({
        nodes: [p.host || "http://localhost:9200"]
    });
    switch (p.action) {
        case "dump":
            await dump(es, p);
            break;
        case "load":
            await load(es, p);
            break;
    }
})();

function parseArgs() {
    const a = [...process.argv];
    const p = {};
    for (let i = 2; i < a.length; i += 2) {
        switch (a[i]) {
            case "-h":
                p.host = a[i + 1];
                break;
            case "-i":
                p.index = a[i + 1];
                p.action = "dump";
                break;
            case "-d":
                p.dir = a[i + 1];
                p.action = "load";
                break;
        }
    }
    return p;
}

async function dump(es, p) {
    const ts = new Date().valueOf();
    const dir = path.join("out", `${p.index}#${ts}`);
    const mappings = await es.indices.getMapping({ index: p.index });
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(
        path.join(dir, "mappings.json"),
        JSON.stringify(mappings.body[p.index], null, 4)
    );
    const settings = await es.indices.getSettings({ index: p.index });
    const { number_of_shards, number_of_replicas } = settings.body[p.index].settings.index;
    fs.writeFileSync(
        path.join(dir, "settings.json"),
        JSON.stringify({ number_of_shards, number_of_replicas }, null, 4)
    );
    let i = 0;
    const filter_path = "_scroll_id,**._id,**._source";
    let res = await es.search({
        index: p.index,
        size: 10000,
        scroll: "1m",
        filter_path
    });
    const scrollId = res.body._scroll_id;
    do {
        fs.writeFileSync(
            path.join(dir, `${p.index}#${i.toString().padStart(3, "0")}.json`),
            JSON.stringify(res.body.hits.hits, null, 4)
        );
        process.stdout.write(".");
        i++;
        res = await es.scroll({
            scrollId: scrollId,
            scroll: "1m",
            filter_path
        });
    } while (((res.body.hits || {}).hits || {}).length);
}

async function load(es, p) {
    const index = path.basename(p.dir).split("#")[0];
    const exists = await es.indices.exists({ index });
    if (!exists.body) {
        const mappings = JSON.parse(fs.readFileSync(path.join(p.dir, "mappings.json"), "utf8"));
        const settings = JSON.parse(fs.readFileSync(path.join(p.dir, "settings.json"), "utf8"));
        const res = await es.indices.create({
            index,
            body: Object.assign(mappings, { settings })
        });
    }
    const files = fs.readdirSync(p.dir).filter(o => o.startsWith(index + "#"));
    for (let file of files) {
        const data = JSON.parse(fs.readFileSync(path.join(p.dir, file), "utf8"));
        const res = await es.bulk({
            index,
            body: data.flatMap(o => [{ index: { _id: o._id } }, o._source])
        });
        if (res.body.errors || res.body.items.filter(o => o.error)) {
            console.error(
                [
                    ...new Set(
                        res.body.items.filter(o => o.index.error).map(o => o.index.error.reason)
                    )
                ].join("\n")
            );
        }
        process.stdout.write(".");
    }
}
